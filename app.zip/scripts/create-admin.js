// Crée (ou met à jour) le compte admin dans MongoDB.
// Utilisation : node scripts/create-admin.js "email@exemple.com" "MonMotDePasse"
//
// Charge MONGODB_URI depuis .env.local (pas besoin du package dotenv).
const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");
const { MongoClient } = require("mongodb");

function loadEnvLocal() {
  const envPath = path.join(__dirname, "..", ".env.local");
  if (!fs.existsSync(envPath)) return;
  const lines = fs.readFileSync(envPath, "utf-8").split("\n");
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const eqIndex = trimmed.indexOf("=");
    if (eqIndex === -1) continue;
    const key = trimmed.slice(0, eqIndex).trim();
    const value = trimmed.slice(eqIndex + 1).trim();
    if (!(key in process.env)) process.env[key] = value;
  }
}

loadEnvLocal();

async function main() {
  const email = process.argv[2];
  const password = process.argv[3];

  if (!email || !password) {
    console.error(
      'Utilisation : node scripts/create-admin.js "email@exemple.com" "MonMotDePasse"'
    );
    process.exit(1);
  }

  const uri = process.env.MONGODB_URI;
  if (!uri) {
    console.error("MONGODB_URI n'est pas défini dans .env.local");
    process.exit(1);
  }

  const client = new MongoClient(uri);
  await client.connect();
  const db = client.db("asc_yaakar");

  const passwordHash = bcrypt.hashSync(password, 10);
  const normalizedEmail = email.toLowerCase().trim();

  await db.collection("admins").updateOne(
    { email: normalizedEmail },
    { $set: { email: normalizedEmail, passwordHash, createdAt: new Date() } },
    { upsert: true }
  );

  console.log(`\nCompte admin prêt : ${normalizedEmail}\n`);
  await client.close();
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
